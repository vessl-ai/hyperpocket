from insert_calendar_events.__main__ import main

__all__ = ["main"]