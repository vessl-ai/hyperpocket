from get_calendar_list.__main__ import main

__all__ = ["main"]