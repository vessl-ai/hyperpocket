from list_pull_request_reviews.__main__ import main

__all__ = [main]
