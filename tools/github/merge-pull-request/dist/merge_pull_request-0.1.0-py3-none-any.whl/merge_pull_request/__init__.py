from merge_pull_request.__main__ import main

__all__ = ["main"]
