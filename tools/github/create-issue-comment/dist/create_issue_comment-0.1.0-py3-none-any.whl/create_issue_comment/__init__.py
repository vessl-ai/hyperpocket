from create_issue_comment.__main__ import main

__all__ = ["main"]
