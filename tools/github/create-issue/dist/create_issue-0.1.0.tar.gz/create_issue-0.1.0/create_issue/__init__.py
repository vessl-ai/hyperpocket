from create_issue.__main__ import main

__all__ = ["main"]
