from watch_repo.__main__ import main

__all__ = ["main"]
