from list_pull_requests.__main__ import main

__all__ = [main]
