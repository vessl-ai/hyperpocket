from list_issues.__main__ import main

__all__ = ["main"]
