from star_repo.__main__ import main

__all__ = ["main"]
