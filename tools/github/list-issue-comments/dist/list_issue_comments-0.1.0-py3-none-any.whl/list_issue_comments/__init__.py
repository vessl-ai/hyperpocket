from list_issue_comments.__main__ import main

__all__ = ["main"]
