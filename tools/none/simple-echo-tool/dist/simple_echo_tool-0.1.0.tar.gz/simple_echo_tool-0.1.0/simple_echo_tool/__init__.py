from simple_echo_tool.__main__ import main

__all__ = ["main"]