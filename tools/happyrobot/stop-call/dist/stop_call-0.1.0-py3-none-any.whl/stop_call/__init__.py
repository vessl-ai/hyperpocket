from stop_call.__main__ import main

__all__ = ["main"]
