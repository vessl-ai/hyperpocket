from get_transcript.__main__ import main

__all__ = ["main"]
