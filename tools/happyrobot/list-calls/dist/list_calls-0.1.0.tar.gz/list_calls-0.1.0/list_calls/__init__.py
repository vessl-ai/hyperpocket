from list_calls.__main__ import main

__all__ = ["main"]
