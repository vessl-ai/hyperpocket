from .__main__ import main

__all__ = ["main"]
