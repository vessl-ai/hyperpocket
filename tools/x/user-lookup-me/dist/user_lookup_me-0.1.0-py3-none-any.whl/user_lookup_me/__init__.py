from user_lookup_me.__main__ import main

__all__ = ["main"]
