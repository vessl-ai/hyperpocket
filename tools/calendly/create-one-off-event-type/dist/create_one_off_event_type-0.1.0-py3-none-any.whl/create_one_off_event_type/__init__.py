from create_one_off_event_type.__main__ import main

__all__ = ['main']