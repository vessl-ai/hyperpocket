from get_context.__main__ import main

__all__ = ["main"]
