from retrieve_input_schema.__main__ import main

__all__ = ["main"]
